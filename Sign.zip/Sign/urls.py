from django.conf.urls import url
from . import views
urlpatterns = [
    url(r'signup/', views.signup,name='index'),
    url(r'Login/', views.Login,name='signin'),
    url(r'home/', views.home,name='home'),
    url(r'start/', views.start,name='start'),
    url(r'health_index/', views.health_index,name='health_index'),
    url(r'logout/',views.logout,name="logout")
]
