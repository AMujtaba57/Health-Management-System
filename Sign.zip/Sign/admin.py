from django.contrib import admin
from .models import Health_Info

admin.site.register(Health_Info)
