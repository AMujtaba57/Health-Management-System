from django.db import models

class Health_Info(models.Model):
    Username=models.CharField(max_length=100)
    Date=models.CharField(max_length=50)
    Active_time=models.IntegerField(max_length=50)
    Calories=models.IntegerField(max_length=50)
    Distance=models.IntegerField(max_length=50)
    Age=models.IntegerField(max_length=3)
    Country=models.TextField(max_length=50)
    Sleep_time=models.IntegerField(max_length=50)
    
