from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User, auth
from .models import Health_Info
# Create your views here.
def signup(request):
    if request.method=='POST':
        first_name=request.POST['first_name']
        last_name=request.POST['last_name']
        username=request.POST['first_name']
        password1=request.POST['password1']
        password2=request.POST['password2']
        email=request.POST['email']
        if password1==password2:
            if User.objects.filter(username=username).exists():
                messages.info(request,'already exists')
                return render(request,'login/index.html',{'m1':'username ','b':True})
            elif User.objects.filter(email=email).exists():
                messages.info(request,'already exists')
                return render(request,'login/index.html',{'m1':'email ','b':False})
            else:
                user=User.objects.create_user(username=username,password=password1,email=email,first_name=first_name,last_name=last_name)
                user.save()
                return render(request,'login/signin.html')
        else:
           messages.info(request,'passwords does not match')
           return render(request,'login/index.html',{'m1':False})

    else:
           return render(request,'login/index.html')


def Login(request):
    if request.method=='POST':
        username=request.POST['email']
        password=request.POST['password']
        user=auth.authenticate(username=username,password=password)
        if user is not None:
            act_msg="Normal"
            sleep_msg="Normal"
            cal_msg="Normal"
            exer_time="Normal"
            auth.login(request,user)
            request.session['username'] = username
            suggestions=Health_Info.objects.all()
            for suggests in suggestions:
                if suggests.Username==username:
                    act_msg="Normal"
                    sleep_msg="Normal"
                    cal_msg="Normal"
                    exer_time="Normal"
                    if int(suggests.Age)<=10 and int(suggests.Age)>=1:
                        if int(suggests.Active_time)<=20 or int(suggests.Active_time)>50:
                            act_msg="30 mins"
                            exer_time="20 mins"
                        if int(suggests.Sleep_time)<60 or int(suggests.Sleep_time)>240:
                            sleep_msg=" 120 mins"
                        if int(suggests.Calories)< 100 or int(suggests.Calories)>200:
                            cal_msg="take 120 cal"
                    elif int(suggests.Age)<=20 and int(suggests.Age)>=11:
                        if int(suggests.Active_time)<=50 or int(suggests.Active_time)>150:
                            act_msg="90 mins"
                            exer_time="30 mins"
                        if int(suggests.Sleep_time)<60 or int(suggests.Sleep_time)>360:
                            sleep_msg=" 240 mins"
                        if int(suggests.Calories)< 150 or int(suggests.Calories)>250:
                            cal_msg="take 180 cal"
                    elif int(suggests.Age)<=30 and int(suggests.Age)>=21:
                        if int(suggests.Active_time)<=70 or int(suggests.Active_time)>200:
                            act_msg="120 mins"
                            exer_time="40 mins"
                        if int(suggests.Sleep_time)<60 or int(suggests.Sleep_time)>360:
                            sleep_msg=" 240 mins"
                        if int(suggests.Calories)< 150 or int(suggests.Calories)>300:
                            cal_msg="take 200 cal"
                    elif int(suggests.Age)<=40 and int(suggests.Age)>=31:
                        if int(suggests.Active_time)<=50 or int(suggests.Active_time)>150:
                            act_msg="90 mins"
                            exer_time="30 mins"
                        if int(suggests.Sleep_time)<60 or int(suggests.Sleep_time)>360:
                            sleep_msg=" 240 mins"
                        if int(suggests.Calories)< 150 or int(suggests.Calories)>250:
                            cal_msg="take 160 cal"
                    elif int(suggests.Age)<=50 and int(suggests.Age)>=41:
                        if int(suggests.Active_time)<=50 or int(suggests.Active_time)>150:
                            act_msg="90 mins"
                            exer_time="30 mins"
                        if int(suggests.Sleep_time)<60 or int(suggests.Sleep_time)>360:
                            sleep_msg=" 240 mins"
                        if int(suggests.Calories)< 150 and int(suggests.Calories)>250:
                            cal_msg="take 120 cal"

            return render(request,'login/health_index.html',{'username':username,'act_msg':act_msg,'sleep_msg':sleep_msg,'cal_msg':cal_msg,'exer_msg':exer_time,'suggestions':suggestions})
        else:
             messages.info(request,'Invalid Username or Password.')
             return render(request,'login/signin.html',{'m1':True})
    else:
       return render(request,'login/signin.html')

def home(request):
       return render(request,'login/home.html')

def start(request):
       return render(request,'login/start.html')

def health_index(request):
        act =[]
        sleep=[]
        cal=0
        count = 0
        calo=[]
        username = request.session['username']
        suggestions=Health_Info.objects.all()
        for suggests in suggestions:
            cal+=suggests.Calories
            count += 1
        for suggests in suggestions:
            act.append(suggests.Active_time)
            calo.append(suggests.Calories)
            sleep.append(suggests.Sleep_time)
        cal = cal/count
       
        act_msg="Normal"
        sleep_msg="Normal"
        cal_msg="Normal"
        exer_time="Normal"
        if request.method=='POST':
            Date=request.POST['date']
            Active_time=request.POST['active_time']
            Calories=request.POST['calories']
            Distance=request.POST['distance']
            Age=request.POST['age']
            Country=request.POST['country']
            Sleep_time=request.POST['sleep_time']
            health_index=Health_Info(Username=username,Date=Date,Active_time=Active_time,Calories=Calories,Distance=Distance,Age=Age,Country=Country,Sleep_time=Sleep_time)
            health_index.save()
         
            if int(Age)<=10 and int(Age)>=1:
                if int(Active_time)<=20 or int(Active_time)>50:
                    act_msg="30 mins"
                    exer_time="20 mins"
                if int(Sleep_time)<60 or int(Sleep_time)>240:
                    sleep_msg=" 120 mins"
                if int(Calories)< 100 or int(Calories)>200:
                    cal_msg="take 120 cal"
            elif int(Age)<=20 and int(Age)>=11:
                if int(Active_time)<=50 or int(Active_time)>150:
                    act_msg="90 mins"
                    exer_time="30 mins"
                if int(Sleep_time)<60 or int(Sleep_time)>360:
                    sleep_msg=" 240 mins"
                if int(Calories)< 150 or int(Calories)>250:
                    cal_msg="take 180 cal"
            elif int(Age)<=30 and int(Age)>=21:
                if int(Active_time)<=70 or int(Active_time)>200:
                    act_msg="120 mins"
                    exer_time="40 mins"
                if int(Sleep_time)<60 or int(Sleep_time)>360:
                    sleep_msg=" 240 mins"
                if int(Calories)< 150 or int(Calories)>300:
                    cal_msg="take 200 cal"
            elif int(Age)<=40 and int(Age)>=31:
                if int(Active_time)<=50 or int(Active_time)>150:
                    act_msg="90 mins"
                    exer_time="30 mins"
                if int(Sleep_time)<60 or int(Sleep_time)>360:
                    sleep_msg=" 240 mins"
                if int(Calories)< 150 or int(Calories)>250:
                    cal_msg="take 160 cal"
            elif int(Age)<=50 and int(Age)>=41:
                if int(Active_time)<=50 or int(Active_time)>150:
                    act_msg="90 mins"
                    exer_time="30 mins"
                if int(Sleep_time)<60 or int(Sleep_time)>360:
                    sleep_msg=" 240 mins"
                if int(Calories)< 150 and int(Calories)>250:
                    cal_msg="take 120 cal"
      
        return render(request,'login/health_index.html',{'act_msg':act_msg,'sleep_msg':sleep_msg,'cal_msg':cal_msg,'exer_msg':exer_time,'suggestions':suggestions,'cal':cal,'sleep':sleep,'act':act,'call':calo})

def logout(request):
    auth.logout(request)
    return render(request,'login/home.html')



